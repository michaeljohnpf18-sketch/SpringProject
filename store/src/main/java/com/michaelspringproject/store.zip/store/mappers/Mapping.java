package com.michaelspringproject.store.mappers;

public @interface Mapping {

}
