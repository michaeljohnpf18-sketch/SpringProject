package com.michaelspringproject.store.entities;

public interface PaymentService {
    void processPayment(double amount);
}